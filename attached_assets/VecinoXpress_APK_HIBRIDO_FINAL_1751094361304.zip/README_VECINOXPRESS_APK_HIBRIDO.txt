📲 VecinoXpress APK - Modo Híbrido (Funciona con y sin internet)

Este paquete contiene la estructura para compilar como APK instalable:

✅ HTML y JS locales
✅ Acceso a internet si está disponible
✅ No depende de dominio activo
✅ Compatible con tablets, POS y celulares

Puedes usar:

- CapacitorJS: https://capacitorjs.com
- Android Studio + WebView
- PWABuilder con archivos locales

Para compilar: copia el contenido a una carpeta `/assets/www` de tu proyecto Android y empaqueta.

Edward, esta versión garantiza que siempre funcione incluso si el dominio cae o no hay conexión.
